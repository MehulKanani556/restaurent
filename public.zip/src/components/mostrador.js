import React, { useEffect, useState } from "react";
import Header from "./Header";
import { FaMinus, FaPlus } from "react-icons/fa";
import { FaCircleCheck } from "react-icons/fa6";
import { Accordion, Button, Modal } from "react-bootstrap";
import { RiDeleteBin6Fill } from "react-icons/ri";
import { Link, useNavigate } from "react-router-dom";
import Sidenav from "./Sidenav";
import Recipt from "./Recipt";
import Counter from "./Counter";
import { MdRoomService } from "react-icons/md";

const Mostrador = () => {
  const apiUrl = process.env.REACT_APP_API_URL;
  const API = process.env.REACT_APP_IMAGE_URL;
  const token = sessionStorage.getItem("token");
  const [ errors, setErrors ] = useState({});
  const [ cartItems, setCartItems ] = useState(
    JSON.parse(localStorage.getItem("cartItems")) || []
  );

  const [ orderType, setOrderType ] = useState(
    JSON.parse(localStorage.getItem("currentOrder")) || []
  );

  const navigate = useNavigate();

  const [ showAllItems, setShowAllItems ] = useState(false);
  const toggleShowAllItems = () => {
    setShowAllItems(!showAllItems);
  };
  const [ countsoup, setCountsoup ] = useState(1);
  const [ selectedRadio, setSelectedRadio ] = useState("1");
  const [ activeAccordionItem, setActiveAccordionItem ] = useState("0");
  const [ itemToDelete, setItemToDelete ] = useState(null);

  // note
  const [ isEditing, setIsEditing ] = useState(
    Array(cartItems.length).fill(false)
  );
  const handleNoteChange = (index, note) => {
    const updatedCartItems = [ ...cartItems ];
    updatedCartItems[index].note = note;
    setCartItems(updatedCartItems);
  };

  const handleKeyDown = (index, e) => {
    if (e.key === "Enter") {
      const updatedIsEditing = [ ...isEditing ];
      updatedIsEditing[index] = false;
      setIsEditing(updatedIsEditing);
    }
  };

  const handleAddNoteClick = (index) => {
    const updatedIsEditing = [ ...isEditing ];
    updatedIsEditing[index] = true;
    setIsEditing(updatedIsEditing);
    const updatedCartItems = [ ...cartItems ];
    if (!updatedCartItems[index].note) {
      updatedCartItems[index].note = "Nota: ";
      setCartItems(updatedCartItems);
    }
  };

  // cart
  useEffect(() => {
    // Load cart items from localStorage
    const storedCartItems = localStorage.getItem("cartItems");
    const storedCountsoup = localStorage.getItem("countsoup");
    if (storedCartItems) {
      setCartItems(JSON.parse(storedCartItems));
    }
    if (storedCountsoup) {
      setCountsoup(JSON.parse(storedCountsoup));
    }
  }, []); // Empty dependency array to run once on component mount

  useEffect(
    () => {
      // Save cart items to localStorage whenever cartItems or countsoup change
      localStorage.setItem("cartItems", JSON.stringify(cartItems));
      localStorage.setItem("countsoup", JSON.stringify(countsoup));
    },
    [ cartItems, countsoup ]
  );
  const addItemToCart = (item) => {
    const existingItemIndex = cartItems.findIndex(
      (cartItem) => cartItem.id === item.id
    );

    if (existingItemIndex !== -1) {
      const updatedCartItems = cartItems.map(
        (cartItem, index) =>
          index === existingItemIndex
            ? { ...cartItem, count: cartItem.count + 1 }
            : cartItem
      );
      setCartItems(updatedCartItems);
      localStorage.setItem("cartItems", JSON.stringify(updatedCartItems));
      setCountsoup(updatedCartItems.map((item) => item.count));
    } else {
      const newItem = { ...item, count: 1, note: "", isEditing: false };
      setCartItems([ ...cartItems, newItem ]);
      localStorage.setItem(
        "cartItems",
        JSON.stringify([ ...cartItems, newItem ])
      );
    }
  };
  const handleDeleteClick = (itemId) => {
    setItemToDelete(itemId);
    handleShowEditFam();
  };
  const removeItemFromCart = (itemId) => {
    const updatedCartItems = cartItems.filter((item) => item.id !== itemId);

    setCartItems(updatedCartItems);
    localStorage.setItem("cartItems", JSON.stringify(updatedCartItems));

    // Update countsoup to match the new cart items
    const updatedCountsoup = updatedCartItems.map((item) => item.count);
    setCountsoup(updatedCountsoup);
  };
  const decrementItem = (itemId) => {
    const updatedCartItems = cartItems
      .map((item) => {
        if (item.id === itemId) {
          return { ...item, count: Math.max(0, item.count - 1) };
        }
        return item;
      })
      .filter((item) => item.count > 0);

    setCartItems(updatedCartItems);
    localStorage.setItem("cartItems", JSON.stringify(updatedCartItems));
    setCountsoup(updatedCartItems.map((item) => item.count));
  };
  const removeEntireItem = (itemId) => {
    const updatedCartItems = cartItems.filter((item) => item.id !== itemId);
    setCartItems(updatedCartItems);
    localStorage.setItem("cartItems", JSON.stringify(updatedCartItems));
    setCountsoup(updatedCartItems.map((item) => item.count));
  };
  const handleAccordionClick = (value) => {
    setSelectedRadio(value);
  };

  const [ showEditFamDel, setShowEditFamDel ] = useState(false);
  const handleCloseEditFamDel = () => setShowEditFamDel(false);
  const handleShowEditFamDel = () => setShowEditFamDel(true);

  const [ showEditFam, setShowEditFam ] = useState(false);
  const handleCloseEditFam = () => setShowEditFam(false);
  const handleShowEditFam = () => setShowEditFam(true);

  const handleDeleteConfirmation = (id) => {
    removeItemFromCart(id);
    handleCloseEditFam();
    handleShowEditFamDel();

    setTimeout(() => {
      setShowEditFamDel(false);
    }, 2000);
  };

  const handleAccordionSelect = (eventKey) => {
    setActiveAccordionItem(eventKey);
    setSelectedRadio("0");
  };

  const handleFinishEditing = (index) => {
    const updatedCartItems = cartItems.map(
      (item, i) => (i === index ? { ...item, isEditing: false } : item)
    );
    setCartItems(updatedCartItems);
  };

  const getTotalCost = () => {
    return cartItems.reduce(
      (total, item) => total + parseInt(item.price) * item.count,
      0
    );
  };
  const totalCost = getTotalCost();
  const discount = 1.0;
  const finalTotal = totalCost - discount;

  const [ rut1, setRut1 ] = useState("");
  const [ rut2, setRut2 ] = useState("");
  const [ rut3, setRut3 ] = useState("");

  const handleRutChange = (e, setRut) => {
    let value = e.target.value.replace(/[^0-9kK-]/g, ""); // Remove any existing hyphen
    if (value.length > 6) {
      value = value.slice(0, 6) + "-" + value.slice(6);
    }
    setRut(value);
    // Clear the RUT error
  setErrors((prevErrors) => ({
    ...prevErrors,
    rut: undefined
  }));
  };

  // ***************************************************API**************************************************
  // form

  const [ formData, setFormData ] = useState({
    fname: "",
    lname: "",
    tour: "",
    address: "",
    email: "",
    number: "",
    bname: "",
    tipoEmpresa: "0"
  });
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: undefined
    }));
  };

  const collectAccordionData = () => {
    const commonData = {
      receiptType: selectedRadio,
      rut: selectedRadio === "1" ? rut1 : selectedRadio === "2" ? rut2 : rut3,
      firstname: formData.fname,
      lastname: formData.lname,
      tour: formData.tour,
      address: formData.address,
      email: formData.email,
      phone: formData.number
    };

    let specificData = {};

    if (selectedRadio === "3") {
      specificData = {
        business_name: formData.bname,
        ltda: formData.ltda
      };
    }

    return { ...commonData, ...specificData };
  };
  const validateForm = (data) => {
    const errors = {};
    
    // RUT validation
    if (!data.rut || data.rut.length < 7) {
      errors.rut = "El RUT debe tener al menos 7 caracteres";
    }
  
    // Name validation
    if (data.receiptType !== "4") {
      if (!data.firstname || data.firstname.trim() === "") {
        errors.fname = "Se requiere el primer nombre";
      }
    }
  
    // Business name validation for receipt type 4
    if (data.receiptType === "4") {
      if (!data.business_name || data.business_name.trim() === "") {
        errors.business_name = "Se requiere el nombre de la empresa";
      }
      if (!data.ltda || data.ltda === "0") {
        errors.ltda = "Seleccione una opción";
      }
    }
  
    // Last name validation
    if (!data.lastname || data.lastname.trim() === "") {
      errors.lname = "El apellido es obligatorio";
    }
  
    // Tour validation
    if (!data.tour || data.tour.trim() === "") {
      errors.tour = "Se requiere tour";
    }
  
    // Address validation
    if (!data.address || data.address.trim() === "") {
      errors.address = "La dirección es necesaria";
    }
  
  
    return errors;
  };
  const handleSubmit = () => {
    const collectedData = collectAccordionData();
    const validationErrors = validateForm(collectedData);
  
    setErrors(validationErrors);
    console.log(collectedData);
    console.log(errors);
    if (Object.keys(validationErrors).length === 0) {
      // No errors, proceed with form submission
      localStorage.setItem("payment", JSON.stringify(collectedData));
      navigate("/counter/payment");
    } else {
      // Scroll to the first error
      const firstErrorField = document.querySelector('.text-danger');
      if (firstErrorField) {
        firstErrorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };

  useEffect(() => {
    const storedOrder = JSON.parse(localStorage.getItem("currentOrder")) || {};
    setOrderType(storedOrder);
  }, []);
  const handleOrderTypeChange = (e) => {
    const newOrderType = e.target.value;
    const updatedOrder = { ...orderType, orderType: newOrderType };
    setOrderType(updatedOrder);
    localStorage.setItem("currentOrder", JSON.stringify(updatedOrder));
  };

  return (
    <div>
      <Header />
      <div className="s_bg_dark">
        <div className="j-flex">
          <div>
            <Sidenav />
          </div>
          <div className="flex-grow-1 sidebar j-position-sticky text-white">
            <div className="j-counter-header">
              <h2 className="text-white mb-3 sjfs-18">Mostrador</h2>
              <div className="j-menu-bg-color">
                <div className="j-tracker-mar d-flex justify-content-between ">
                  <div className="line1 flex-grow-1">
                    <Link
                      to={"/counter"}
                      className="text-decoration-none px-2 sj_text_dark"
                    >
                      <FaCircleCheck className="mx-1" />
                      <span>Artículos</span>
                    </Link>
                  </div>
                  <div className="flex-grow-1 text-center">
                    <Link className="text-decoration-none px-2 j-counter-path-color">
                      <FaCircleCheck className="mx-1" />
                      <span>Datos</span>
                    </Link>
                  </div>
                  <div className="line2 flex-grow-1 text-end">
                    <Link
                      to={"/counter/payment"}
                      className="text-decoration-none px-2 sj_text_dark"
                    >
                      <FaCircleCheck className="mx-1" />
                      <span>Pago</span>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-2 mx-2 sj_hwidth">
              <div className="bg_gay p-4">
                <p className="mb-2">Datos cliente</p>
                <p>Tipos de comprobantes</p>
                <hr className="sj_bottom" />
                <Accordion defaultActiveKey={[ "0" ]} className="sj_accordion">
                  <Accordion.Item eventKey="0" className="mb-2">
                    <Accordion.Header>
                      <div
                        onClick={() => handleAccordionClick("1")}
                        className={`sj_bg_dark px-4 py-2 sj_w-75 ${activeAccordionItem ===
                        "1"
                          ? "active"
                          : ""}`}
                      >
                        <input
                          type="radio"
                          name="receiptType"
                          value="1"
                          checked={selectedRadio === "1"}
                          onChange={() => setSelectedRadio("1")}
                          className="me-2 j-radio-checkbox"
                        />
                        <p className="d-inline px-3">Boleta nominativa:</p>
                      </div>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div className="sj_gay_border px-3 py-4 mt-2 j_mos_size">
                        <form>
                          <div className="row j_col_width">
                            <div className="col-12 mb-2">
                              <label className="mb-2">Rut </label>
                              <input
                                type="text"
                                name="rut1"
                                value={rut1}
                                onChange={(e) => handleRutChange(e, setRut1)}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.rut && <div className="text-danger errormessage">{errors.rut}</div>}
                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Nombre </label>
                              <input
                                type="text"
                                id="fname"
                                name="fname"
                                value={formData.fname}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.fname && <div className="text-danger errormessage">{errors.fname}</div>}

                            </div>
                            <div className="col-6">
                              <label className="mb-2">Apellido Paterno </label>
                              <input
                                type="text"
                                id="id"
                                name="lname"
                                value={formData.lname}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.lname && <div className="text-danger errormessage">{errors.lname}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Giro </label>
                              <input
                                type="text"
                                id="id"
                                name="tour"
                                value={formData.tour}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.tour && <div className="text-danger errormessage">{errors.tour}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Dirección </label>
                              <input
                                type="text"
                                id="id"
                                name="address"
                                value={formData.address}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.address && <div className="text-danger errormessage">{errors.address}</div>}

                            </div>
                            <div className="col-6 ">
                              <label className="mb-2">E-mail (opcional) </label>
                              <input
                                type="text"
                                id="id"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                            </div>
                            <div className="col-6 ">
                              <label className="mb-2">
                                Teléfono móvil (opcional){" "}
                              </label>
                              <input
                                type="text"
                                id="id"
                                name="number"
                                value={formData.number}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                            </div>
                          </div>
                        </form>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>

                  <Accordion.Item eventKey="2" className="mb-2">
                    <Accordion.Header>
                      <div
                        onClick={() => handleAccordionClick("2")}
                        className={`sj_bg_dark px-4 py-2 sj_w-75 ${activeAccordionItem ===
                        "2"
                          ? "active"
                          : ""}`}
                      >
                        <input
                          type="radio"
                          name="receiptType"
                          value="1"
                          checked={selectedRadio === "2"}
                          onChange={() => setSelectedRadio("2")}
                          className="me-2 j-radio-checkbox"
                        />
                        <p className="d-inline px-3">Boleta electrónica:</p>
                      </div>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div className="sj_gay_border px-3 py-4 mt-2 j_mos_size">
                        <form>
                          <div className="row  j_col_width">
                            <div className="col-12 mb-2">
                              <label className="mb-2">Rut </label>
                              <input
                                type="text"
                                name="rut2"
                                value={rut2}
                                onChange={(e) => handleRutChange(e, setRut2)}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.rut && <div className="text-danger errormessage">{errors.rut}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Nombre </label>
                              <input
                                type="text"
                                id="id"
                                name="fname"
                                value={formData.fname}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.fname && <div className="text-danger errormessage">{errors.fname}</div>}

                            </div>
                            <div className="col-6">
                              <label className="mb-2">Apellido Paterno </label>
                              <input
                                type="text"
                                id="id"
                                name="lname"
                                value={formData.lname}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.lname && <div className="text-danger errormessage">{errors.lname}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Giro </label>
                              <input
                                type="text"
                                id="id"
                                name="tour"
                                value={formData.tour}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.tour && <div className="text-danger errormessage">{errors.tour}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Dirección </label>
                              <input
                                type="text"
                                id="id"
                                name="address"
                                value={formData.address}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.address && <div className="text-danger errormessage">{errors.address}</div>}

                            </div>
                            <div className="col-6 ">
                              <label className="mb-2">E-mail (opcional) </label>
                              <input
                                type="text"
                                id="id"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                            </div>
                            <div className="col-6 ">
                              <label className="mb-2">
                                Teléfono móvil (opcional){" "}
                              </label>
                              <input
                                type="text"
                                id="id"
                                name="number"
                                value={formData.number}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                            </div>
                          </div>
                        </form>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>

                  <Accordion.Item eventKey="4" className="mb-2">
                    <Accordion.Header>
                      <div
                        className={`sj_bg_dark px-4 py-2 sj_w-75 ${activeAccordionItem ===
                        "4"
                          ? "active"
                          : ""}`}
                        onClick={() => handleAccordionClick("4")}
                      >
                        <input
                          type="radio"
                          name="receiptType"
                          value="4"
                          checked={selectedRadio === "4"}
                          onChange={() => setSelectedRadio("4")}
                          className="me-2 j-radio-checkbox"
                        />
                        <p className="d-inline px-3">Factura:</p>
                      </div>
                    </Accordion.Header>
                    <Accordion.Body>
                      <div className="sj_gay_border px-3 py-4 mt-2 j_mos_size">
                        <form>
                          <div className="row  j_col_width">
                            <div className="col-6 mb-2">
                              <label className="mb-2">Rut </label>
                              <input
                                type="text"
                                name="rut3"
                                value={rut3}
                                onChange={(e) => handleRutChange(e, setRut3)}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.rut && <div className="text-danger errormessage">{errors.rut}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Razón Social </label>
                              <input
                                type="text"
                                id="id"
                                name="bname"
                                value={formData.bname}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.business_name && <div className="text-danger errormessage">{errors.business_name}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Sa, Ltda, Spa </label>
                              <select
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white form-select"
                                name="ltda"
                                value={formData.ltda}
                                onChange={handleInputChange}
                              >
                                <option value="0">Seleccionar opción</option>
                                <option value="sa">Sa</option>
                                <option value="ltda">Ltda</option>
                                <option value="spa">Spa</option>
                              </select>
                              {errors.ltda && <div className="text-danger errormessage">{errors.ltda}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Apellido Paterno</label>
                              <input
                                type="text"
                                id="id"
                                name="lname"
                                value={formData.lname}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.lname && <div className="text-danger errormessage">{errors.lname}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Giro </label>
                              <input
                                type="text"
                                id="id"
                                name="tour"
                                value={formData.tour}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.tour && <div className="text-danger errormessage">{errors.tour}</div>}

                            </div>
                            <div className="col-6 mb-2">
                              <label className="mb-2">Dirección </label>
                              <input
                                type="text"
                                id="id"
                                name="address"
                                value={formData.address}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                              {errors.address && <div className="text-danger errormessage">{errors.address}</div>}

                            </div>
                            <div className="col-6 ">
                              <label className="mb-2">E-mail (opcional) </label>
                              <input
                                type="text"
                                id="id"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                            </div>
                            <div className="col-6 ">
                              <label className="mb-2">
                                Teléfono móvil (opcional){" "}
                              </label>
                              <input
                                type="text"
                                id="id"
                                name="number"
                                value={formData.number}
                                onChange={handleInputChange}
                                className="sj_bg_dark sj_width_input ps-2 pe-4 py-2 text-white"
                              />
                            </div>
                          </div>
                        </form>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
              </div>
            </div>
          </div>
          <div
            className="j-counter-price j_position_sticky"
            style={{ top: "77px" }}
          >
            <div className="j_position_fixed j_b_hd_width">
              <h2 className="text-white j-kds-body-text-1000">Resumen</h2>
              <div className="j-counter-price-data">
                <h3 className="text-white j-kds-body-text-1000">Datos</h3>
                <div className="j-orders-inputs j_inputs_block">
                  <div className="j-orders-code">
                    <label className="j-label-name text-white mb-2 j-tbl-font-6 ">
                      Código pedido
                    </label>
                    <input
                      className="j-input-name j_input_name2"
                      type="text"
                      placeholder="01234"
                      value={orderType.orderId}
                    />
                  </div>
                  <div className="j-orders-type me-2">
                    <label className="j-label-name  text-white mb-2 j-tbl-font-6 ">
                      Tipo pedido
                    </label>
                    <select
                      className="form-select j-input-name-2 j-input-name-23"
                      onChange={handleOrderTypeChange}
                      value={orderType.orderType}
                    >
                      <option value="0">Seleccionar</option>
                      <option value="delivery">Entrega</option>
                      <option value="local">Local</option>
                      <option value="withdraw">Retirar</option>
                    </select>
                  </div>
                </div>

                {cartItems.length === 0 ? (
                  <div>
                    <div className="b-product-order text-center">
                      <MdRoomService className="i-product-order" />
                      <h6 className="h6-product-order text-white j-tbl-pop-1">
                        Mesa disponible
                      </h6>
                      <p className="p-product-order j-tbl-btn-font-1">
                        Agregar producto para empezar<br />
                        con el pedido de la mesa
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="j-counter-order j_counter_width">
                    <h3 className="text-white j-tbl-font-5">Pedido </h3>

                    <div className={`j-counter-order-data `}>
                      {(showAllItems
                        ? cartItems
                        : cartItems.slice(0, 3)).map((item, index) => (
                        <div className="j-counter-order-border-fast">
                          <div className="j-counter-order-img" key={item.id}>
                            <div className="d-flex align-items-center justify-content-between">
                              <img src={`${API}/images/${item.image}`} alt="" />
                              <h5 className="text-white j-tbl-pop-1">
                                {item.name}
                              </h5>
                            </div>
                            <div className="d-flex align-items-center">
                              <div className="j-counter-mix">
                                <button
                                  className="j-minus-count"
                                  onClick={() => decrementItem(item.id)}
                                >
                                  <FaMinus />
                                </button>
                                <h3 className="j-tbl-btn-font-1">
                                  {item.count}
                                </h3>
                                <button
                                  className="j-plus-count"
                                  onClick={() => addItemToCart(item)}
                                >
                                  <FaPlus />
                                </button>
                              </div>
                              <h4 className="text-white fw-semibold j-tbl-text-14">
                                ${parseInt(item.price)}
                              </h4>
                              <button
                                className="j-delete-btn"
                                onClick={() => {
                                  handleDeleteClick(item.id);
                                  handleShowEditFam();
                                }}
                              >
                                <RiDeleteBin6Fill />
                              </button>
                            </div>
                          </div>

                          <div className="text-white j-order-count-why">
                            {item.isEditing ? (
                              <div>
                                <input
                                  className="j-note-input"
                                  type="text"
                                  value={item.note}
                                  onChange={(e) =>
                                    handleNoteChange(index, e.target.value)}
                                  onBlur={() => handleFinishEditing(index)}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter")
                                      handleFinishEditing(index);
                                  }}
                                  autoFocus
                                />
                              </div>
                            ) : (
                              <div>
                                {item.note ? (
                                  <p className="j-nota-blue">{item.note}</p>
                                ) : (
                                  <button
                                    className="j-note-final-button"
                                    onClick={() => handleAddNoteClick(index)}
                                  >
                                    + Agregar nota
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                      {cartItems.length > 3 && (
                        <Link onClick={toggleShowAllItems} className="sjfs-14">
                          {showAllItems ? "Ver menos" : "Ver más"}
                        </Link>
                      )}
                    </div>
                    <div className="j-counter-total">
                      <h5 className="text-white j-tbl-text-15">Costo total</h5>
                      <div className="j-total-discount d-flex justify-content-between">
                        <p className="j-counter-text-2">Artículos</p>
                        <span className="text-white">
                          ${totalCost.toFixed(2)}
                        </span>
                      </div>
                      <div className="j-border-bottom-counter">
                        <div className="j-total-discount d-flex justify-content-between">
                          <p className="j-counter-text-2">Descuentos</p>
                          <span className="text-white">
                            {cartItems.length > 0 ? (
                              `$${discount.toFixed(2)}`
                            ) : (
                              "$0.00"
                            )}
                          </span>
                        </div>
                      </div>
                      <div className="j-total-discount my-2 d-flex justify-content-between">
                        <p className="text-white bj-delivery-text-153 ">
                          Total
                        </p>
                        <span className="text-white bj-delivery-text-153 ">
                          {cartItems.length > 0 ? (
                            `$${finalTotal.toFixed(2)}`
                          ) : (
                            "$0.00"
                          )}
                        </span>
                      </div>
                      <div
                        className="btn w-100 j-btn-primary text-white m-articles-text-2"
                        onClick={handleSubmit}
                      >
                        Continuar
                      </div>
                    </div>
                    <Modal
                      show={showEditFam}
                      onHide={handleCloseEditFam}
                      backdrop={true}
                      keyboard={false}
                      className="m_modal jay-modal"
                    >
                      <Modal.Header closeButton className="border-0" />
                      <Modal.Body className="border-0">
                        <div className="text-center">
                          <img
                            className="j-trash-img-late"
                            src={require("../Image/trash-outline-secondary.png")}
                            alt=""
                          />
                          <p className="mb-0 mt-2 j-kds-border-card-p">
                            Seguro deseas eliminar este pedido
                          </p>
                        </div>
                      </Modal.Body>
                      <Modal.Footer className="border-0 justify-content-center">
                        <Button
                          className="j-tbl-btn-font-1 "
                          variant="danger"
                          onClick={() => {
                            removeEntireItem(itemToDelete);
                            handleCloseEditFam();
                            handleShowEditFamDel();
                          }}
                        >
                          Si, seguro
                        </Button>
                        <Button
                          className="j-tbl-btn-font-1 "
                          variant="secondary"
                          onClick={() => {
                            handleCloseEditFam();
                          }}
                        >
                          No, cancelar
                        </Button>
                      </Modal.Footer>
                    </Modal>
                    <Modal
                      show={showEditFamDel}
                      onHide={handleCloseEditFamDel}
                      backdrop={true}
                      keyboard={false}
                      className="m_modal jay-modal"
                    >
                      <Modal.Header closeButton className="border-0" />
                      <Modal.Body>
                        <div className="j-modal-trash text-center">
                          <img
                            src={require("../Image/trash-outline.png")}
                            alt=""
                          />
                          <p className="mb-0 mt-3 h6 j-tbl-pop-1">
                            Order eliminado
                          </p>
                          <p className="opacity-75 j-tbl-pop-2">
                            El Order ha sido eliminado correctamente
                          </p>
                        </div>
                      </Modal.Body>
                    </Modal>
                  </div>
                )}
                <Modal
                  show={showEditFam}
                  onHide={handleCloseEditFam}
                  backdrop={true}
                  keyboard={false}
                  className="m_modal jay-modal"
                >
                  <Modal.Header closeButton className="border-0" />
                  <Modal.Body className="border-0">
                    <div className="text-center">
                      <img
                        className="j-trash-img-late"
                        src={require("../Image/trash-outline-secondary.png")}
                        alt=""
                      />
                      <p className="mb-0 mt-2 j-kds-border-card-p">
                        Seguro deseas eliminar este pedido
                      </p>
                    </div>
                  </Modal.Body>
                  <Modal.Footer className="border-0 justify-content-center">
                    <Button
                      className="j-tbl-btn-font-1 "
                      variant="danger"
                      onClick={() => handleDeleteConfirmation(itemToDelete)}
                    >
                      Si, seguro
                    </Button>
                    <Button
                      className="j-tbl-btn-font-1 "
                      variant="secondary"
                      onClick={() => {
                        handleCloseEditFam();
                      }}
                    >
                      No, cancelar
                    </Button>
                  </Modal.Footer>
                </Modal>

                <Modal
                  show={showEditFamDel}
                  onHide={handleCloseEditFamDel}
                  backdrop={true}
                  keyboard={false}
                  className="m_modal jay-modal"
                >
                  <Modal.Header closeButton className="border-0" />
                  <Modal.Body>
                    <div className="j-modal-trash text-center">
                      <img src={require("../Image/trash-outline.png")} alt="" />
                      <p className="mb-0 mt-3 h6 j-tbl-pop-1">
                        Pedido eliminado
                      </p>
                      <p className="opacity-75 j-tbl-pop-2">
                        El Pedido ha sido eliminado correctamente
                      </p>
                    </div>
                  </Modal.Body>
                </Modal>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Mostrador;
