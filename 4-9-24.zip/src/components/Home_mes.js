import { useState, useCallback } from "react";
import { Container, Row, Col, Image } from "react-bootstrap";
import Home_contMes from "./Home_contMes";
import Home_Messages from "./Home_Messages";
import Header from "./Header";
import Sidenav from "./Sidenav";
import avatar from '../img/Avatar.png';

const Home_mes = () => {
    const [selectedContact, setSelectedContact] = useState(null);

    const onNavItemContainerClick = useCallback(() => {
        // Please sync "Home - Pedidos" to the project
    }, []);

    return (
        <Container fluid className="p-0" style={{ backgroundColor: "#111928", minHeight: "100vh", color: "#fff" }}>
            <Header />
            <div className="j-sidebar-nav">
                <Sidenav />
            </div>

            <div className="jay-chat-column">
                <Row className="flex-nowrap">
                    <Col xs={2} className="j-bg-dark-500 j-final-border-end p-0 jc-position-fixed sidebar">
                        <Home_contMes setSelectedContact={setSelectedContact} />
                    </Col>
                    <Col xs={7} className="p-0">
                        {selectedContact ? (
                            <Home_Messages contact={selectedContact} />
                        ) : (
                           <div className=""></div>
                        )}
                    </Col>
                </Row>
            </div>
        </Container>
    );
};

export default Home_mes;
